from django.db import models

# No model created for now