from django.contrib import admin

# I'll register my model here another time