from django.test import TestCase

# No test is there for now
